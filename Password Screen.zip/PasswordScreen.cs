﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PasswordScreen : MonoBehaviour
{
    public string Password = "password";
    public InputField IInputField;
    public Text EnterPasswordText;
    public GameObject Canvas;
    public int StartScene = 0;

    // Start is called before the first frame update
    void Start()
    {
        IInputField.Select();
        IInputField.ActivateInputField();
        // For developer use, load specific scene at start
        if (StartScene != 0) SceneManager.LoadScene(StartScene);
    }

    // Update is called once per frame
    void Update()
    {
        IInputField.Select();
        IInputField.ActivateInputField();
        if (Input.GetKey(KeyCode.Return))
        {
            if (IInputField.text != "")
            {
                if (IInputField.text == Password)
                {
                    IInputField.text = "";
                    EnterPasswordText.text = "Correct password! Welcome USER!";
                    SceneManager.LoadScene(1);
                    Canvas.GetComponent<PasswordScreen>().enabled = false; // Don't remove this
                }
                else if (IInputField.text == "betaloadmain")
                {
                    IInputField.text = "";
                    EnterPasswordText.text = "Welcome beta tester!";
                    SceneManager.LoadScene(3);
                    Canvas.GetComponent<PasswordScreen>().enabled = false; // Don't remove this
                }
                else
                {
                    EnterPasswordText.text = "Wrong password! Please try again:";
                }
                IInputField.text = "";
            }
        }
    }

    public void OnQuit()
    {
        Application.Quit();
    }    
}
